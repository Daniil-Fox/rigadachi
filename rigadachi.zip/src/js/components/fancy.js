import { Fancybox } from "@fancyapps/ui";

Fancybox.bind("[data-fancybox=gallery]", {});
